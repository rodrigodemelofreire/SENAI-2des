const user = {
    username: 'admin',
    password: '1234',
};

export default user;